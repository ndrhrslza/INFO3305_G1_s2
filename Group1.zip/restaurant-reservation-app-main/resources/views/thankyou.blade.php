<x-guest-layout>
  <div class="container w-full px-5 py-6 mx-auto">
    <h1>Thankyou</h1>
    <p>You Reservation is Ready</p>
  </div>
</x-guest-layout>